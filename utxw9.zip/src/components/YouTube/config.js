const config = {
  api_key: "AIzaSyAaTMOefWukgakjUjW_HI9tZ5tInWN10Rs",
  channel_id: "UCU4IxmvkyulPNrdhkZCz_zw"
};
export default config;
